import './style.css';
import { createApi } from 'unsplash-js';

const unsplash = createApi({
  accessKey: import.meta.env.VITE_ACCESS_KEY,
});

// HEADER
const headerTemplate = () => {
  return `
    <h1>I</h1>
    <input type="text" placeholder="Search" id="searchinput"/>
    <button id="searchbtn"><img src="./src/assets/search.svg" alt="Search icon"/></button>
    <button id="darkmodebtn"><img src="./src/assets/dark.png" alt="Dark mode icon" id="darkmodeicon"></button>
    <img src="./src/assets/profile.png" alt="Profile image" class="profileimg"/> 
  `;
};

const themeSwitch = () => {
  document.body.classList.toggle('dark');
  const isDark = document.body.classList.contains('dark');
  document.querySelector('#darkmodeicon').src = isDark ? './src/assets/light.png' : './src/assets/dark.png';
};

const listeners = () => {
  document.querySelector('#darkmodebtn').addEventListener('click', themeSwitch);
  document.querySelector('#searchbtn').addEventListener('click', handleSearch);
};

const printHeaderTemplate = () => {
  document.querySelector('header').innerHTML = headerTemplate();
  listeners();
};

// FOOTER
const templateFooter = () => `<h4>Copyright 2023 - Inspirest - Rock the Code</h4>`;

const printFooterTemplate = () => {
  document.querySelector('footer').innerHTML = templateFooter();
};

// BÚSQUEDA UNSPLASH
const buscarImagenes = async (palabraClave) => {
  try {
    const respuesta = await unsplash.search.getPhotos({
      query: palabraClave,
      page: 1,
      perPage: 12,
    });

    return respuesta.response.results;
  } catch (error) {
    console.error('Error al obtener imágenes:', error);
    return [];
  }
};

const cardTemplate = (item) => {
  return `
    <li class="gallery-item" style="background-image: url(${item.urls.regular}); border: 10px solid ${item.color}">
      <div class="info">
        <div class="save-btn">
          <button>Guardar</button>
        </div>
        <div class="links">
          <a href="${item.links.html}" target="_blank" class="full-link">Ver en Unsplash</a>
          <div>
            <a href="${item.urls.full}" target="_blank" class="links-icon">
              <img src="/icons/upload.svg" alt="Upload icon"/>
            </a>
            <a href="#null" class="links-icon">
              <img src="/icons/more.svg" alt="More icon"/>
            </a>    
          </div>
        </div>
      </div>
    </li>
  `;
};

const mostrarImagenes = async (palabraClave) => {
  const imagenes = await buscarImagenes(palabraClave);
  const galeria = document.querySelector('main');
  galeria.innerHTML = '<ul class="gallery"></ul>';

  const lista = document.querySelector('.gallery');
  imagenes.forEach((img) => {
    lista.innerHTML += cardTemplate(img);
  });
};

const handleSearch = () => {
  const input = document.querySelector('#searchinput');
  const query = input.value.trim();
  if (query) {
    mostrarImagenes(query);
  }
};

printHeaderTemplate();
printFooterTemplate();
